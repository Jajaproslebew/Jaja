<?php

session_start();
    include  "koneksi.php";

    $username = $_POST['Username'];
    $password = $_POST['password'];

$login = mysqli_query($mysqli,"select * from user where username='$username' and password='$password'");
$cek = mysqli_num_rows($login);

if($cek > 0){
// log in as user
if($data['level']=="user"){
    // session log in dan username
    $_SESSION   ['username'] = $username;
    $_SESSION ['level'] = "user";
    // dashboard user
    header("location:halaman setelah login/index.php");
}
}else{
    header("location:index.php?pesan=gagal");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="stylelogin.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman form login</title>
</head>
<body>
    <div class="kotak login">
        <p class="tulisan_login">Silahkan login </p>
        <form action="cek login.php" method="post" role="form">
        <label>Username</label>
        <input type="text" name="Username" class="Form_login" placeholder="username" autocomplete="off" required>
        <label>password</label>
        <input type="text" name="password" class="Form_login" placeholder="password" autocomplete="off" required>
        <button>login</button>
        <input type="submit" class="tombol_login" value="login">
</form>
<a href="Register.php">Register</a>

    </div>
</body>
</html>



<?php
// error_reporting(0);
// session_start();
$databasehost = "localhost";
$databasename = "login";
$username = "root";
$password = "";
$connection = mysqli_connect($databasehost, $username, $password,$databasename) or die (mysql_error());



?>
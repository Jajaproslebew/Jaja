<body>
<div class="container">
<h1>Register</h1>
        <form action="Register.php" method="post" name="form1">
            <table>
            
                <tr>
                    <td>Username</td>
                    <td><input type="teks" name="username" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td>level</td>
                    <td>
                    <select name="level" id="level" required>
                    <option disabled selected> Pilih </option>>
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                    </select>
                    </td>
                </tr>
                <tr>
                    <td><button class="btn" name="submit"> Daftar</button></td>
                </tr>

            </table>
                <?php
                if(isset($_POST['submit'])){
                 $usernames =$_POST['username'];
                  $passwords = $_POST['password'];
                  $levels = $_POST['level'];

                

             //echo($judul);
                // include database connection file
               // Include_once("koneksi.php");
                include "koneksi.php";
                // Insert user data into table
             $result = mysqli_query($connection, "INSERT INTO tb_login (username,password,level) VALUES ('$usernames','$passwords','$levels')");
             
             header("location: login.php");
                }
             ?>
             


            
        </form>
</div>
</body>